#pragma once

#include "mls/core_types.h"

namespace mlspp {

void
grease(Capabilities& capabilities, const ExtensionList& extensions);

void
grease(ExtensionList& extensions);

} // namespace mlspp
