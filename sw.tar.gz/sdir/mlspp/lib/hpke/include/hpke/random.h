#pragma once

#include <bytes/bytes.h>
using namespace mlspp::bytes_ns;

namespace mlspp::hpke {

bytes
random_bytes(size_t size);

} // namespace mlspp::hpke
