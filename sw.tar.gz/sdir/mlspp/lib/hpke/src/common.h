#pragma once

#include <hpke/hpke.h>

namespace mlspp::hpke {

bytes
i2osp(uint64_t val, size_t size);

} // namespace mlspp::hpke
