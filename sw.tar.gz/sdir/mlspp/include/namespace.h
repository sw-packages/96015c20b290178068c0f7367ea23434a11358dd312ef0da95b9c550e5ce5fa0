#pragma once

// Configurable top-level MLS namespace
#define MLS_NAMESPACE mls
