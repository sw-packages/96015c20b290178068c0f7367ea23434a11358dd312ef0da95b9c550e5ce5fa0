#pragma once

/* Global version strings */
extern const char VERSION[];
extern const char HASHVAR[];
